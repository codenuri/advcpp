// const member function
#include <iostream>
#include <set>

class Point
{
	int x{ 0 }, y{ 0 };
public:
	Point() = default;
	Point(int x, int y) : x(x), y(y) {}

	bool operator<(const Point& pt) 
	{
		return x < pt.x;
	}
};

int main()
{
	std::set<Point> s;

	s.emplace(1, 2); // error.  s.insert( Point(1,2) )
}
