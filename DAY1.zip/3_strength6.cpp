// explicit 
#include <iostream>

struct empty1 { empty1() = default; };

struct vector1 
{ 
	vector1(std::size_t size) {} 
};
struct vector2
{
	vector2(std::size_t size) {}
};

void f1(vector1 v) {}
void f2(vector2 v) {}

int main()
{	
	vector v1(10);
	vector v1 = 10;
}