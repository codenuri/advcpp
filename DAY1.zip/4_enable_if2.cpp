#include <iostream>



template<typename T>
T foo(T a)  { std::cout << "T" << std::endl; return 0; }

int foo(...) { std::cout << "..." << std::endl; return 0; }

int main()
{
	foo(3); 
}