﻿#include <iostream>

// 멤버 변수 포인터
struct Point
{
	int x{ 0 };
	int y{ 0 };
};

int main()
{
	int n = 0;
	int* p1 = &n;

}
