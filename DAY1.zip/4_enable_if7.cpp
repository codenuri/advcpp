// trivial3번 복사
