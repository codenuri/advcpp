// checked_delete

#include <iostream>


struct Object
{
	Object()  { std::cout << "Object()" << std::endl; }
	~Object() { std::cout << "~Object()" << std::endl; }
};

void deleter(Object* p)
{
	delete p;
}

int main()
{
	Object* p = new Object();
	deleter(p);
}