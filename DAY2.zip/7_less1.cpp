#include <iostream>

template <typename T>
struct less
{
    constexpr bool operator()(const T& lhs, const T& rhs) const
    {
        return lhs < rhs;
    }
};

int main()
{
    less<int> f;

    bool ret = f(10, 20);
}