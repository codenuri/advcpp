#include <iostream>
#include <string>

class Card
{
};

void init(const Card& c)
{
}

int main()
{
	Card c;
	init(c);
}