#include <iostream>

class Vector
{
	int buff[5] = { 1,2,3,4,5 };
public:
};

int main()
{
	int n1;

	Vector v1;

	v1[0] = 10;
	n1 = v1[0];

}