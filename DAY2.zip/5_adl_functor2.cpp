#include <iostream>
#include <string>

class mystring {};

mystring operator+(const mystring& s1, const mystring& s2)
{
	return s1;
}

int main()
{
	mystring s1;
	mystring s2;

	operator+(s1, s2);
}