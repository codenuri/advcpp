#include <iostream>
#include <functional>
#include <string>

template<typename T>
const T& max(const T& lhs, const T& rhs)
{
	return lhs < rhs ? rhs : lhs;
}

int main()
{
	int ret = max(10, 3);
}