// noexcept
#include <iostream>

template<typename T>
[[nodiscard]] constexpr const T& 
max(const T& lhs, const T& rhs) 
{
	return lhs < rhs ? rhs : lhs;
}

int main()
{
	auto ret = max(1, 2);

	std::cout << ret << std::endl;
}