#include <iostream>
#include <Windows.h>

DWORD __stdcall foo(void* p)
{
	std::cout << "foo" << std::endl;
	return 0;
}

int main()
{
	CreateThread(0, 0, foo, "A", 0, 0); 										
	getchar();
}