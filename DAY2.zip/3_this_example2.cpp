#define USING_GUI
#include "cppmaster.h""
#include <map>

void foo(int id)
{
	std::cout << "foo : " << id << std::endl;
}

int main()
{
	int id1 = ec_set_timer(1000, foo);
	int id2 = ec_set_timer(500, foo); 

	ec_process_message(); 
}
