#include <iostream>

class Object
{
	int x = 0;
public:
	void f1(int a) 
	{
	}
};

int main()
{
	Object obj;
	obj.f1(10);
}