#include <iostream>
#include <new>

int main()
{
    int* p1 = new int[10];  // 실패시 std::bad_alloc 예외 발생
    delete[] p1;
}
