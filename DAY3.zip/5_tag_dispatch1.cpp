#include <iostream>
#include <mutex>

template <typename Mutex> class lock_guard 
{ 
    Mutex& mtx;
public:
    explicit lock_guard(Mutex& mtx)  : mtx(mtx) { if ( autolock ) mtx.lock();}
    ~lock_guard() noexcept { mtx.unlock(); }
};

std::mutex m;

void foo()
{
    m.lock();

    m.unlock();
}

int main()
{
    foo();
}


