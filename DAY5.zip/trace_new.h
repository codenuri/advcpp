#pragma once
#include <new>      
#include <cstdio>   
#include <stdlib.h>

int cnt = 0;

void* operator new (std::size_t size)
{
    ++cnt;
    return malloc(size);
}

void* operator new[](std::size_t size)
{
    ++cnt;
    return malloc(size);
}

void operator delete (void* p) noexcept
{
    std::free(p);
}

void operator delete (void* p, std::size_t) noexcept
{
    std::free(p);
}

void operator delete[](void* p) noexcept
{
    std::free(p);
}

void report()
{
    printf("%d allocations\n", cnt);
}