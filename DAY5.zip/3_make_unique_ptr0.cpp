#include <iostream>
#include <memory>

class Car
{
public:
    ~Car()    { std::cout << "~Car" << std::endl; }
    void Go() { std::cout << "Car Go" << std::endl; }
};
int main()
{
	std::unique_ptr<Car> p = new Car; 
	std::unique_ptr<Car> p(new Car);  

	p->Go();
	(*p).Go();

	std::unique_ptr<Car> p1 = p; 
	std::unique_ptr<Car> p2 = std::move(p);

	Car* cp = p2.get();
	p2.reset();
}