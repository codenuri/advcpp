#include <iostream>
#include <string>
#include <vector>
#include "trace_new.h"

int main()
{

    std::vector<std::string> v;

    for (int i = 0; i < 1000; ++i) 
    {    
        v.emplace_back("to be or not to be");
    }
    report();
}
