#include <iostream>
#include <any>

struct Point
{
	int x, y;

	Point(int a, int b) : x(a), y(b) {}
};

int main()
{
	std::string s = "hello";
	std::any a1 = 10;
	std::any a2 = 3.4;
	std::any a3 = s;

	Point pt(1, 2);
	std::any a4 = pt;

	Point p = std::any_cast<Point>(a4);

}