#include <vector>
#include <iostream>

int main()
{
	std::vector v = { 1, 2, 3, 4, 5 };

	for (auto e : v)
	{
		std::cout << e << std::endl;
	}

	auto first = v.begin();
	auto last = v.end();

	for( ; first != last; ++first )
	{
		auto e = *first;
		std::cout << e << std::endl;
	}
}

