#include <iostream>
#include <type_traits>
#include <functional>
#include "compressed_pair.h"

int main()
{
    compressed_pair<int, Point> p1(one_and_var, 10, 1, 2);
    compressed_pair<int, Point> p2(one_and_var, 10);      
    compressed_pair<int, Point> p3(zero_and_var, 1, 2);   
    compressed_pair<Empty, int> p4(zero_and_var, 1);

}

