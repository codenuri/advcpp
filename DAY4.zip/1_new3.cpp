#include <iostream>
#include <vector>

int main()
{
	std::vector<int> v(10, 3);

	v.resize(7);  // 이 순간의 원리를 생각해 봅시다.
}




