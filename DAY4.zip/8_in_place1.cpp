#include <iostream>
#include <string>
#include <optional>

int foo()
{
	// 실패를 반환하고 싶다.
	return 0;
}

int main()
{
	auto ret = foo();
}

