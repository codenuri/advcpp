#include <iostream>

class Point
{
	int x;
	int y;
public:
//	Point() : x(0), y(0) { std::cout << "Point()" << std::endl; }
	Point(int a, int b) : x(a), y(b) { std::cout << "Point(int, int)" << std::endl; }
	~Point() { std::cout << "~Point()" << std::endl; }
};

int main()
{
	// 힙에 Point 한개를 만들려면 아래 처럼 하면 됩니다.
	Point* p1 = new Point(0, 0);

	// 힙에 Point 10개를 만들어 보세요

}




