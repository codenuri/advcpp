#include <iostream>

template<typename T> class MyAlloc
{
public:
	// allocate, deallocate ...

};

template<typename T> void foo(T ax)
{
	// 현재 T 는 MyAlloc<bool>
	// MyAlloc<bool> => MyAlloc<int> 로 변경

}

int main()
{
	MyAlloc<bool> ax;
	foo(ax);
}
