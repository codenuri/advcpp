#include <iostream>
#include <vector>

class DBConnect
{
public:
	DBConnect() { std::cout << "DBConnect()" << std::endl; }
	~DBConnect() { std::cout << "~DBConnect()" << std::endl; }
};

int main()
{
	std::vector<DBConnect> v(5);

	v.resize(3);


	v.resize(4);
}




